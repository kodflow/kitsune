package socket_test

import (
	"testing"

	"github.com/kodmain/kitsune/src/internal/core/server/protocols/socket"
	"github.com/kodmain/kitsune/src/internal/core/server/transport"
	"github.com/stretchr/testify/assert"
)

func TestClient(t *testing.T) {
	server := socket.NewServer("localhost:8080")
	server.Start()
	defer server.Stop()

	client := socket.NewClient("localhost:8080")

	t.Run("NewClient", func(t *testing.T) {
		assert.NotNil(t, client, "Expected client to be non-nil")
		assert.Equal(t, "localhost:8080", client.Address)
	})

	t.Run("ConnectAndClose", func(t *testing.T) {
		err := client.Connect()
		assert.Nil(t, err, "Expected no error on connecting")

		err = client.Connect()
		assert.NotNil(t, err, "Expected error on connecting already done")

		err = client.Disconnect()
		assert.Nil(t, err, "Expected no error on closing")

		err = client.Disconnect()
		assert.NotNil(t, err, "Expected error on closing already closed connection")

		err = client.Connect()
		assert.Nil(t, err, "Expected no error on connecting")
	})

	t.Run("RequestAndResponse", func(t *testing.T) {
		client.Connect()
		req := transport.CreateRequest()
		promise, err := client.Send(req)
		assert.Nil(t, err, "Expected no error on sending request")
		assert.NotNil(t, promise, "Expected promise of response")
	})

	t.Run("RequestOnly", func(t *testing.T) {
		client.Connect()
		req := transport.CreateRequestOnly()
		promise, err := client.Send(req)
		assert.Nil(t, err, "Expected no error on sending request")
		assert.NotNil(t, promise, "Expected promise of response")
	})

}

func BenchmarkRequestsOnly(b *testing.B) {
	server := socket.NewServer("localhost:8080")
	server.Start()
	defer server.Stop()

	client := socket.NewClient("localhost:8080")
	client.Connect()
	defer client.Disconnect()

	b.ResetTimer() // Ne compte pas la configuration initiale dans le temps de benchmark

	for i := 0; i < b.N; i++ {
		req := transport.CreateRequestOnly()
		client.Send(req)
	}
}

func BenchmarkRequestAndResponse(b *testing.B) {
	server := socket.NewServer("localhost:8080")
	server.Start()

	client := socket.NewClient("localhost:8080")
	client.Connect()

	b.ResetTimer() // Ne compte pas la configuration initiale dans le temps de benchmark

	for i := 0; i < b.N; i++ {
		req := transport.CreateRequest()
		client.SendSync(req)
	}

	client.Disconnect()
	server.Stop()
}
