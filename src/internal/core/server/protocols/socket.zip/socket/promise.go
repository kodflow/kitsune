package socket

import (
	"github.com/kodmain/kitsune/src/internal/core/server/transport"
)

// Promise is used to manage the async response mechanism.
type promise struct {
	wait chan *transport.Response // wait is a channel used to await the response.
}

// Wait waits for a response and returns it.
func (p *promise) Wait() *transport.Response {
	if p.wait == nil {
		return nil
	}

	res := <-p.wait

	return res
}

func (p *promise) Init() {
	p.wait = make(chan *transport.Response)
}

func Promise() *promise {
	return &promise{}
}
